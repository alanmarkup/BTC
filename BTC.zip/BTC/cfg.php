<?php

//BAHAN YANG PERLU DIINSTAL DI TERMUX
//[1]. pkg install php
//[2]. pkg install tesseract
//[3]. pkg install imagemagick
//Sampai Sini sudah Paham Kan 
//Jangan Lupa Subscribe Chanel Penghasil Gratisa


$ua = "Mozilla/5.0 (Linux; Android 9; RMX1911) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.96 Mobile Safari/537.36";

$PHPSESSID = "PHPSESSID=gs48lcsdqs68237f77ic37vi9n";

$get_id = "get_id=139699";
